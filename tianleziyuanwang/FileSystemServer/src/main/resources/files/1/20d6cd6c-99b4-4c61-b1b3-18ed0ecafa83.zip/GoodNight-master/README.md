# GoodNight
Auto saying good night to girlfriend

## Usage

1. Make sure Node.js and npm installed.
2. Run `npm install` to install all dependencies.
3. Run `npm start` to start the application.
